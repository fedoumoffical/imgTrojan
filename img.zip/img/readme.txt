
██╗███╗   ███╗ ██████╗    ███████╗██╗  ██╗███████╗
██║████╗ ████║██╔════╝    ██╔════╝╚██╗██╔╝██╔════╝
██║██╔████╔██║██║  ███╗   █████╗   ╚███╔╝ █████╗  
██║██║╚██╔╝██║██║   ██║   ██╔══╝   ██╔██╗ ██╔══╝  
██║██║ ╚═╝ ██║╚██████╔╝██╗███████╗██╔╝ ██╗███████╗
╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
                                                  
Malware name: img.exe
Malware type: Destroy
Type: noskid
By: FedouM
Description: This is a Win32.Kill.Trojan with PayloadMBR! Thanks for watching readme!